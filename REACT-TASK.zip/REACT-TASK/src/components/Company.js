import React,{useState} from 'react'
import Employee from './Employee'

function Company() {
    const [firstname, setfirstname] = useState('')
    const handleSubmit = (e) => {
        e.preventDefault()
    }
    return (
        <div>
            <form onSubmit={e => {handleSubmit(e)}}>
                <label>
                    FirstName:
                    <input type="text" value={firstname} onChange={e => setfirstname(e.target.value)} />
                </label>

            </form>
            <br />
            <br />
            <br />
            <Employee Fname={firstname}  />
            
        </div>
    )
}

export default Company
