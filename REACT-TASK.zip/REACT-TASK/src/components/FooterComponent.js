import React from 'react';
export default function Footer(){
 return(
   <div  style={{marginBottom:"0"}}> 
    <footer className="page-footer #aa00ff purple accent-4" >

    <div className="footer-copyright">
      <div className="container">
      © 2021 Copyright 
      <p className="grey-text text-lighten-4 right">www.assignment.com</p>
      </div>
    </div>
  
  </footer>
  </div>
 )

}