import React,{useState} from 'react';
import Company from './CompanyComponent';
export default function Home(){

 

 return(
     <div style={{height:"120vh"}}>
     
     <h3>Home</h3>
       <h4> hello, i have done this project with  reactjs</h4>
     </div>
 )

}